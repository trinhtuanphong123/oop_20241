WIDTH = 800  # Chiều rộng của bàn cờ (đơn vị pixel)
HEIGHT = 800  # Chiều cao của bàn cờ (đơn vị pixel)

COLS = 8  # Số cột của bàn cờ
ROWS = 8  # Số hàng của bàn cờ
SQ_SIZE = WIDTH // COLS  # Kích thước mỗi ô vuông (pixel) trên bàn cờ