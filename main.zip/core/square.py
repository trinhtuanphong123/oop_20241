class Square:
    __slots__ = ('row', 'col', 'piece')  # Giới hạn các thuộc tính để tiết kiệm bộ nhớ
    
    def __init__(self, row, col, piece=None):
        """
        Khởi tạo một ô vuông trên bàn cờ.
        :param row: Hàng (chỉ số từ 0-7).
        :param col: Cột (chỉ số từ 0-7).
        :param piece: Quân cờ trên ô này (mặc định là None nếu ô trống).
        """
        self.row = row
        self.col = col
        self.piece = piece

    def __eq__(self, other):
        """
        So sánh hai ô vuông dựa trên hàng và cột.
        :param other: Một đối tượng khác để so sánh.
        :return: True nếu hàng và cột giống nhau, ngược lại False.
        """
        return isinstance(other, Square) and self.row == other.row and self.col == other.col

    def __hash__(self):
        """
        Tạo giá trị băm cho đối tượng Square (để sử dụng trong set hoặc dict).
        """
        return hash((self.row, self.col))
            
    def has_piece(self):
        """
        Kiểm tra xem ô vuông có chứa quân cờ không.
        :return: True nếu có quân cờ, ngược lại False.
        """
        return self.piece is not None
        
    def isempty(self):
        """
        Kiểm tra xem ô vuông có trống không.
        :return: True nếu ô trống, ngược lại False.
        """
        return not self.has_piece()  # Sử dụng lại has_piece để tránh lặp logic
        
    def has_team_piece(self, color):
        """
        Kiểm tra xem ô vuông có quân cờ của đội người chơi hay không.
        :param color: Màu của quân cờ (ví dụ: 'white' hoặc 'black').
        :return: True nếu ô chứa quân cùng màu, ngược lại False.
        """
        return self.has_piece() and self.piece.color == color  # Tận dụng has_piece
        
    def has_enemy_piece(self, color):
        """
        Kiểm tra xem ô vuông có quân cờ của đối thủ hay không.
        :param color: Màu của người chơi.
        :return: True nếu ô chứa quân của đối thủ, ngược lại False.
        """
        return self.has_piece() and self.piece.color != color  # Tận dụng has_piece
        
    def isempty_or_enemy(self, color):
        """
        Kiểm tra xem ô vuông có trống hoặc có quân của đối thủ không.
        :param color: Màu của người chơi.
        :return: True nếu ô trống hoặc có quân đối thủ, ngược lại False.
        """
        return self.isempty() or self.has_enemy_piece(color)  # Kết hợp isempty và has_enemy_piece
        
    @staticmethod
    def in_range(*args):
        """
        Kiểm tra xem các chỉ số hàng và cột có nằm trong phạm vi bàn cờ (0-7) không.
        :param args: Các giá trị cần kiểm tra.
        :return: True nếu tất cả giá trị nằm trong phạm vi, ngược lại False.
        """
        return all(0 <= arg <= 7 for arg in args)
