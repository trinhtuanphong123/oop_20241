from .king import King
from .queen import Queen
from .bishop import Bishop
from .rook import Rook
from .knight import Knight
from .pawn import Pawn