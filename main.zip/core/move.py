from .square import Square

class Move:
    __slots__ = ('initial', 'final')
    
    def __init__(self, initial: Square, final: Square):
        self.initial = initial
        self.final = final
            
    def __eq__(self, other):
        if not isinstance(other, Move):
            return False
        return self.initial == other.initial and self.final == other.final

    def __hash__(self):
        return hash((self.initial, self.final))

    def __repr__(self):
        return f"Move({self.initial} -> {self.final})"
