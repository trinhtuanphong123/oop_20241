import copy
from const import ROWS, COLS
from core.pieces.pawn import Pawn
from core.pieces.king import King
from .square import Square
from contextlib import contextmanager


class GameLogic:
    def __init__(self, board):
        self.board = board  # Bàn cờ
        self.next_player = 'white'  # Lượt chơi tiếp theo
        self.last_move = None  # Nước đi cuối cùng

    def next_turn(self):
        """Chuyển lượt chơi."""
        self.next_player = 'white' if self.next_player == 'black' else 'black'

    def set_en_passant(self, move):
        """Cập nhật trạng thái en passant cho quân Tốt."""
        for row in range(ROWS):
            for col in range(COLS):
                square = self.board.squares[row][col]
                if isinstance(square.piece, Pawn):
                    square.piece.en_passant = False

        # Nếu quân Tốt đi 2 ô, bật trạng thái en passant
        piece = self.board.squares[move.initial.row][move.initial.col].piece
        if isinstance(piece, Pawn) and abs(move.final.row - move.initial.row) == 2:
            piece.en_passant = True

    def in_check(self, color, move=None):
        """
        Kiểm tra xem vua của người chơi có bị chiếu không.
        :param color: Màu của người chơi.
        :param move: Nước đi để kiểm tra (nếu có).
        :return: True nếu bị chiếu, ngược lại False.
        """
        with self.simulate_move_in_place(move):
            king_position = self.get_king_position(color)

            if king_position is None:
                raise ValueError(f"King for color '{color}' not found on the board.")

            # Kiểm tra xem có quân nào tấn công vua
            for row in range(ROWS):
                for col in range(COLS):
                    square = self.board.squares[row][col]
                    if square.has_enemy_piece(color):
                        piece = square.piece
                        piece.calc_moves(row, col, self.board, self, validate=False)
                        if any(
                            m.final.row == king_position[0] and m.final.col == king_position[1]
                            for m in piece.moves
                        ):
                            return True
        return False

    def get_king_position(self, color):
        """Tìm vị trí của quân vua."""
        for row in range(ROWS):
            for col in range(COLS):
                square = self.board.squares[row][col]
                if square.has_piece() and isinstance(square.piece, King) and square.piece.color == color:
                    return square.row, square.col
        return None

    def calculate_all_moves(self, color, validate=True):
        """
        Tính toán tất cả các nước đi cho người chơi.
        :param color: Màu sắc của người chơi.
        :param validate: Kiểm tra tính hợp lệ của nước đi.
        :return: Danh sách các nước đi hợp lệ.
        """
        moves = []
        for row in range(ROWS):
            for col in range(COLS):
                square = self.board.squares[row][col]
                if square.has_team_piece(color):
                    piece = square.piece
                    piece.clear_moves()
                    piece.calc_moves(row, col, self.board, self)

                    if validate:
                        piece.moves = [
                            move for move in piece.moves if not self.in_check(color, move)
                        ]
                    moves.extend(piece.moves)
        return moves

    def is_checkmate(self, color):
        """Kiểm tra chiếu hết."""
        if self.in_check(color):
            return len(self.calculate_all_moves(color)) == 0
        return False

    def is_stalemate(self, color):
        """Kiểm tra hòa cờ."""
        if not self.in_check(color):
            return len(self.calculate_all_moves(color)) == 0
        return False

    @contextmanager
    def simulate_move_in_place(self, move):
        """
        Giả lập nước đi trên bàn cờ và hoàn tác sau khi kiểm tra.
        :param move: Nước đi cần giả lập.
        """
        if not move:
            yield
            return

        piece = self.board.squares[move.initial.row][move.initial.col].piece
        target_piece = self.board.squares[move.final.row][move.final.col].piece

        # Thực hiện giả lập
        self.board.squares[move.initial.row][move.initial.col].piece = None
        self.board.squares[move.final.row][move.final.col].piece = piece
        piece.moved = True

        try:
            yield
        finally:
            # Hoàn tác nước đi
            self.board.squares[move.initial.row][move.initial.col].piece = piece
            self.board.squares[move.final.row][move.final.col].piece = target_piece
            piece.moved = False
